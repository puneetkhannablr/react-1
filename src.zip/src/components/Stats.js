import "./styles/ExpenseItem.css";
import React from "react";
function Stats(props) {
  return <div>Stats</div>;
}

export default Stats;
